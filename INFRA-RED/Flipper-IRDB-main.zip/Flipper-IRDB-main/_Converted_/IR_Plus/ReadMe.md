# [IR Plus App](https://play.google.com/store/apps/details?id=net.binarymode.android.irplus) converted by [sasiplavnik](https://github.com/sasiplavnik/)

Cleaned up by [Hans Gruber](https://github.com/sasiplavnik/Flipper-IRDB/commit/6fb6bb06c5156bcf2eaa98e64675607c2c55458d) and notified about it's existence by [yarabin](https://github.com/yarbabin)

Organized into folders and merged into IRDB by [UberGuidoZ](https://github.com/UberGuidoZ)
