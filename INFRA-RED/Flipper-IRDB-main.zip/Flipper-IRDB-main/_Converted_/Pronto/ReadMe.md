# Pronto files converted by SkeletonMan

Cleaned up by and tested by [UberGuidoZ](https://github.com/UberGuidoZ) and [Amec0e](https://github.com/amec0e)

Organized into folders and merged into IRDB by [UberGuidoZ](https://github.com/UberGuidoZ)
